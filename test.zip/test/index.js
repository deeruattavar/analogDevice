var fs=require('fs');

var contents=fs.readFileSync("data.bin")
process.stdout.write(contents.slice(0,48))
console.log(contents)
var arr=[0,7,20,34]
var text='';
var start=0
var res=[]

    for(let a =0;a<arr.length;a++){
    for(let i=arr[a]+1;i<contents[arr[a]]+arr[a]+1;i++)
    {
        //console.log(String.fromCharCode(contents[i]))
        text+=String.fromCharCode(contents[i])+""
        
        
    }
    res.push(text)
}

console.log(res);




