
/*
  for(let i=start+1;i<contents[start]+0;i++)
    {
        //console.log(String.fromCharCode(contents[i]))
        text+=String.fromCharCode(contents[i])+""

    }

*/


//console.log(contents[0]) //6
//console.log(contents[7]) //12
//console.log(contents[20])//13
//console.log(contents[34])//14
// 1,13,15,16
//0,1    6,13 , 12,14   ,13,15